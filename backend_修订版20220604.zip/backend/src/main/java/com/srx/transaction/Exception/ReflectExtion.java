package com.srx.transaction.Exception;

public class ReflectExtion extends RuntimeException {
    public ReflectExtion(String message) {
        super(message);
    }
}
