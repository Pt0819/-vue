package com.srx.transaction.Exception;

public class PathException extends RuntimeException{
    public PathException(String message) {
        super(message);
    }
}
