package com.srx.transaction.Serivce;

public interface BaseService {
}
